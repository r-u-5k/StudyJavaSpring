package com.itwill.guest.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class GuestRestController {

}
