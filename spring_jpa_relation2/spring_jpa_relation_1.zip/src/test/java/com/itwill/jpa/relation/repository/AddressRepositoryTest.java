package com.itwill.jpa.relation.repository;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.itwill.SpringJpaApplicationTests;
import com.itwill.jpa.relation.entity.Address;
import com.itwill.jpa.relation.entity.Student;
import com.itwill.jpa.relation.entity.Tutor;

class AddressRepositoryTest extends SpringJpaApplicationTests{
	@Autowired
	AddressRepository addressRepository;
	@Autowired
	StudentRepository studentRepository;
	@Test
	@Disabled
	void savAddressWithStudents() {
		
		Address address=Address.builder()
				.street("강릉호텔")
				.city("강릉")
				.state("강원")
				.zip("343434")
				.country("대한민국")
				.build();
		
		Student student1=Student.builder()
				.name("학생1")
				.email("student1@gmai.com")
				.dob(new Date())
				.phone("111-22222")
			   .build();
		Student student2=Student.builder()
				.name("학생2")
				.email("student2@gmai.com")
				.dob(new Date())
				.phone("333-4444")
				.build();
		
		
		
		
	}
	@Test
	@Disabled
	void savAddressWithTutors() {
		
		Address address=Address.builder()
				.street("강릉호텔")
				.city("강릉")
				.state("강원")
				.zip("343434")
				.country("대한민국")
				.build();
		
		Tutor tutor1=Tutor.builder()
				.name("김강사1")
				.email("kim1@gmail.com")
				.phone("111-1111")
				.dob(LocalDateTime.now())
				.build();
		Tutor tutor2=Tutor.builder()
				.name("김강사2")
				.email("kim2@gmail.com")
				.phone("222-2222")
				.dob(LocalDateTime.now().minusMonths(3))
				.build();
		
		
	}
	@Test
	@Disabled
	@Transactional
	void selectAddressWithStudents() {
		
	}

}
