package com.itwill.jpa.relation.repository;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.itwill.SpringJpaApplicationTests;
import com.itwill.jpa.relation.entity.Address;
import com.itwill.jpa.relation.entity.Student;

class StudentRepositoryTest extends SpringJpaApplicationTests {
	@Autowired
	StudentRepository studentRepository;
	@Autowired
	AddressRepository addressRepository;
	@Test
	@Disabled
	void saveStudentWithAddress() {
		Address address=Address.builder()
				.street("강릉호텔")
				.city("강릉")
				.state("강원")
				.zip("343434")
				.country("대한민국")
				.build();
		
		Student student=Student.builder()
						.name("학생1")
						.email("student1@gmai.com")
						.dob(new Date())
						.phone("111-22222")
						.build();
		
	
	}
	@Test
	@Disabled
	void selectStudentWithAddress() {
		
	}

}
