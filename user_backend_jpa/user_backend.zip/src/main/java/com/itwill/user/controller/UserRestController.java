package com.itwill.user.controller;

/*
POST 	/user/login 		- login  user 
GET   	/user/logout		- logout user 
POST 	/user 				- create user 
PUT 	/user/{id} 			- modify user by {id}
GET 	/user/{id} 			- GETs the details of the user with {id}
DELETE 	/user/{id} 			- Delete the user with id 
*/

public class UserRestController {
	
	
	
	
	
}
