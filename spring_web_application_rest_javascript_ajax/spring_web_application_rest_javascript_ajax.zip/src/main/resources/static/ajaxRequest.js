function ajaxRequest(method,url,params,callbackFunction){
	
	
}