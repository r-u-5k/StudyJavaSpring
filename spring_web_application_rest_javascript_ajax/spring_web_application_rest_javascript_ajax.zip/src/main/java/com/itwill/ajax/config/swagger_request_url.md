
 - http://localhost/spring_web_application_rest_javascript_ajax/swagger-ui/index.html