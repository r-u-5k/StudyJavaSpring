package com.itwill.ajax.config;

import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;


public class SwaggerConfig {
	/*
	@Bean
	public GroupedOpenApi chatOpenApi() {
		String[] paths = { "/v1/**" };
		return GroupedOpenApi.builder().group("COUPLE API v1").pathsToMatch(paths).build();
	}
	*/

}